import undetected_chromedriver as uc
import time
from selenium.webdriver.common.by import By

URL = "https://onlyfinder.com/new-free/profiles/"

driver = uc.Chrome()

driver.get(URL)
time.sleep(10)

while True:
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)
    if driver.current_url == "https://onlyfinder.com/new-free/profiles/936/":
        break
time.sleep(5)
items = driver.find_elements(By.XPATH, "//a[@referrerpolicy='origin']")
items = items[1::2]

with open("text.txt", "w", encoding="utf-8") as string:
    for i in items:
        text = i.find_element(By.XPATH, "./h3").text
        url = i.get_attribute('href')
        string.writelines(f"{text}: {url}\n")

time.sleep(10)
